/**
 * 
 */

function checkData(){
	var userId = document.getElementById("id").value;
	var password = document.getElementById("password").value;
	if (userId == 'a' && password == 'b'){
		alert("bye bye");
	}
}