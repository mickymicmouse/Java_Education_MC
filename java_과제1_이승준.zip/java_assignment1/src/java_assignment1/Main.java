package java_assignment1;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookDTO bd1 = new BookDTO(21424 , "Java Basic", "���ϳ�", "Jaen.kr", 15000, "Java �⺻ ����");
		BookDTO bd2 = new BookDTO(33455 , "JDBC Pro", "��ö��", "Jaen.kr", 23000, "");
		BookDTO bd3 = new BookDTO(55355 , "Servlet/JSP", "���ڹ�", "Jaen.kr", 41000, "Model2 ���");
		BookDTO bd4 = new BookDTO(35332 , "Andorid App", "ȫ�浿", "Jaen.kr", 25000, "Lightweight Framework");
		BookDTO bd5 = new BookDTO(35355 , "OOAD �м�,����", "�ҳ���", "Jaen.kr", 30000, "");
		System.out.println("*******************���� ���*******************");
		System.out.println(bd1);
		System.out.println(bd2);
		System.out.println(bd3);
		System.out.println(bd4);
		System.out.println(bd5);
		
	}
	
	

}
