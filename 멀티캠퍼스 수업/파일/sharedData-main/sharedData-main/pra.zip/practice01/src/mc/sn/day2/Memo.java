package mc.sn.day2;

public class Memo {

	
	
	
	
	
}
