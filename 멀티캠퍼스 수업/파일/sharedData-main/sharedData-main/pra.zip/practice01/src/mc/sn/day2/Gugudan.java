package mc.sn.day2;

public class Gugudan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int k=0;k<8;k++) {
			int dan = k+2;
			for (int i=0;i<9;i++) {
				int number = i+1;
				System.out.println(dan+"X"+number+"="+(dan*number));
			}
			System.out.println();
		}
//		System.out.println("2X2=4");
//		System.out.println("2X3=6");
//		System.out.println("2X4=8");
//		System.out.println("2X5=10");
//		System.out.println("2X6=12");
//		System.out.println("2X7=14");
//		System.out.println("2X8=16");
//		System.out.println("2X9=18");
	}

}
