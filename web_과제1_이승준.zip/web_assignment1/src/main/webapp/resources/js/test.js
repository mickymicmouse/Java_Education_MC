/**
 * 
 */

function checkData(){
	var userId = document.getElementById("id").value;
	var password = document.getElementById("pw").value;
	if (userId == 'a' && password == 'b'){
		alert(userId+":"+password);
	}
}